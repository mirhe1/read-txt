#include "read_txt_data.hpp"
#include <iostream>

int main(int argc, char* argv)
{
	//std::string parameters_string = "1;2;34";
	//int array[30];
	//int a = 0;
	//readtxt::AnalyzeParameterStringToIntarray(parameters_string, array,a);
	//std::cout << array[0];
	//std::cout << array[1];
	//std::cout << array[2];
	//std::cout << a;
	//std::cout << std::endl;

	//std::string s = "1  2   34";
	//std::vector<std::string> row_parameter_vector;
	//readtxt::RowStringSplitBySpace(s, row_parameter_vector);
	//for (std::vector<std::string>::iterator t = row_parameter_vector.begin();t != row_parameter_vector.end();t++)
	//{
	//	std::cout << *t<<std::endl;
	//}
	//std::cout << row_parameter_vector.size() << std::endl;

	const int channel_id = 2;
	std::string parameters_string = "1 2 3 4";
	const std::string read_txt_name = "test.txt";
	const std::string output_txt_name = "out_test.txt";
	readtxt::SelectChannelAndParameters(channel_id, parameters_string, read_txt_name, output_txt_name);


	system("pause");
	return 0;
}