#ifndef TACKLE_TXT_DATA_READ_TXT_DATA
#define TACKLE_TXT_DATA_READ_TXT_DATA
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
/*read data condition define*/
#define  READ_TXT_CONDITION_ONE 1
#define  READ_TXT_CONDITION_TWO ' '
#define  STRING_ZERO '0'
#define  STRING_NINE '9'
#define  INT_ZERO 0
#define  INT_ONE 1

namespace readtxt{
inline bool ChartoInt(const char& c, int& i)
{
	i = c - '0';
	if (typeid(i) != typeid(int))
	{
		return false;
	}
	return true;
}

inline bool StringtoInt(const std::string& s, int& i)
{
	i = atoi(s.c_str());
	if (typeid(i) != typeid(int))
	{
		return false;
	}
	return true;
}

bool ReadTxtProcedure(
	const std::string& read_txt_name,
	const std::string& output_txt_name)
{
	std::ifstream m_cin_txt;
	/*open file by means of only read*/
	m_cin_txt.open(read_txt_name,std::ios::in);
	if (!m_cin_txt.is_open())
	{
		std::cout<< "open read_txt failure!" << std::endl;
		return false;
	}

	std::ofstream m_cout_txt;
	/*creat file while file isn't exist and clear all content when open file*/
	m_cout_txt.open(output_txt_name, std::ios::_Noreplace, std::ios::trunc);
	if (!m_cout_txt.is_open())
	{
		std::cout << "open output_txt failure!" << std::endl;
		return false;
	}

	std::string every_row_data;
	while (std::getline(m_cin_txt,every_row_data))
	{
		/*read data condition*/
		if (every_row_data[2] == READ_TXT_CONDITION_ONE && 
			every_row_data[28] != READ_TXT_CONDITION_TWO)
		{
			m_cout_txt << every_row_data.substr(28);
			/*finish one row write*/
			m_cout_txt << std::endl;
		}
	}
	m_cin_txt.close();
	m_cout_txt.close();
	return true;
}

/*parameters string split into non character*/
bool AnalyzeParameterStringToIntarray(
	const std::string& parameters_string/*in*/,
	int parameters_id_array[]/*out*/,
	int &parameters_id_size/*out*/)
{
	bool successorfalse;
	/*for parameters_id_array*/
	int array_len = INT_ZERO;
	/*for parameters_string*/
	int string_cycle_len = INT_ZERO;
	/*for sub_string_id*/
	int sub_string_len = INT_ZERO;
	/*every parameter id*/
	int parameter_id = INT_ZERO;

	std::string sub_string_id;
	int string_len = parameters_string.size();

	while (string_cycle_len < string_len)
    {
		/*if  parameters_string[string_cycle_len] is non_number_string,save parameter_id into parameters_id_array*/
		if (STRING_ZERO >= parameters_string[string_cycle_len] ||
			STRING_NINE <= parameters_string[string_cycle_len])
		{			
			sub_string_id = parameters_string.substr(string_cycle_len - sub_string_len,
				                                  string_cycle_len);
			successorfalse = StringtoInt(sub_string_id, parameter_id);
			if (successorfalse == false)
			{
				std::cout << "analyze error information: StringtoInt() == false!";
				return false;
			}
			parameters_id_array[array_len] = parameter_id;
			/*sub_string_len reset zero*/
			sub_string_len = INT_ZERO;
			/*next parameters_string index*/
			++string_cycle_len;
			/*next parameters_id index*/
			++array_len;
		}
		else
		{
			/*continue account sub_string_len until parameters_string[string_cycle_len] is non_number_string*/
			++sub_string_len;
			/*next parameters_string index*/
			++string_cycle_len;
		}
    }
	/*save the last parameter_id*/
	sub_string_id = parameters_string.substr(string_cycle_len - sub_string_len,
		                                  string_cycle_len );
	successorfalse = StringtoInt(sub_string_id, parameter_id);
	if (successorfalse == false)
	{
		std::cout << "analyze error information: StringtoInt() == false!";
		return false;
	}
	parameters_id_array[array_len] = parameter_id;
	/*because index start to 0,size = max_index + 1*/
	parameters_id_size = array_len + INT_ONE;
	if (parameters_id_size == INT_ONE)
	{
		std::cout << "analyze error information: parameters_id_size == 1!";
		return false;
	}
	return true;
}

bool RowStringSplitBySpace(
	const std::string& every_row_data/*in*/,
	std::vector<std::string>& row_parameter_vector/*out*/)
{
	int row_current_len = INT_ZERO;
	int row_len = every_row_data.size();
	std::string sub_string;
	int sub_string_len = INT_ZERO;
	while (row_current_len < row_len)
	{
		/*if every_row_data[row_current_len] is number_string, write into sub_string*/
		if (STRING_ZERO <= every_row_data[row_current_len] &&
			STRING_NINE >= every_row_data[row_current_len])
		{
			sub_string.append(1,every_row_data[row_current_len]);
			++row_current_len;
			++sub_string_len;
		}
		else
		{
			/*when every_row_data[row_current_len] is non_number_string and the first time write into row_parameter_vector*/
			if (sub_string_len != INT_ZERO)
			{
				row_parameter_vector.push_back(sub_string);
				sub_string.erase(sub_string.begin(), sub_string.end());
				/*when write into row_parameter_vector later, sub_string_len reset zero,
				avoid next char is non_number_string write into vector*/
				sub_string_len = INT_ZERO;
			}
			/*continue next cycle*/
			++row_current_len;
		}
	}
	/*the last sub_string push into vector*/
	row_parameter_vector.push_back(sub_string);
	/*delete channel from vector,make vector only include parameters*/
	row_parameter_vector.erase(row_parameter_vector.begin());
	if (row_parameter_vector.empty())
	{
		std::cout << "RowStringSplitBySpace() error information: row_parameter_vector is empty!";
		return false;
	}
	return true;
}

bool SelectChannelAndParameters(
	const int channel_id,
	const std::string& parameters_string,
	const std::string& read_txt_name, 
	const std::string& output_txt_name)
{
	bool successorfalse = false;
	std::ifstream m_cin_txt;
	/*open file by means of only read*/
	m_cin_txt.open(read_txt_name, std::ios::in);
	if (!m_cin_txt.is_open())
	{
		std::cout << "open read_txt failure!" << std::endl;
		return successorfalse;
	}
	std::ofstream m_cout_txt;
	/*creat file while file isn't exist and clear all content when open file*/
	m_cout_txt.open(output_txt_name, std::ios::trunc);
	if (!m_cout_txt.is_open())
	{
		std::cout << "open output_txt failure!" << std::endl;
		return successorfalse;
	}
	/*acquire chosen parameters_id int array*/
	int parameters_id_array[30] = {};
	int parameters_id_size = INT_ZERO;
	successorfalse = AnalyzeParameterStringToIntarray(parameters_string, parameters_id_array, parameters_id_size);
	if (successorfalse == false)
	{
		std::cout << "AnalyzeParameterStringToIntarray() error !";
		return successorfalse;
	}
	/*read txt_data by channel and chosen parameters id conditions*/
	std::string every_row_data;
	std::vector<std::string> row_parameter_vector;

	while (std::getline(m_cin_txt, every_row_data))
	{
		int varible = INT_ZERO;
		successorfalse = ChartoInt(every_row_data[0], varible);
		if (successorfalse == false)
		{
			std::cout << "ChartoInt() error !";
			return successorfalse;
		}
		if (varible == channel_id)
		{
			/*make row string into vector which include all parameters by the space*/
			successorfalse = RowStringSplitBySpace(every_row_data, row_parameter_vector);
			if (successorfalse == false)
			{
				std::cout << "RowStringSplitBySpace() error !";
				return successorfalse;
			}
			int iterator_count = INT_ONE;  /*parameter id begin with 1*/
			int loop_varianle = INT_ZERO;
			for (std::vector<std::string>::iterator t = row_parameter_vector.begin();
				t != row_parameter_vector.end() && loop_varianle < parameters_id_size;
				t++)
			{
				while (parameters_id_array[loop_varianle] == iterator_count )
				{
					/*write into_txt when is the chosen parameter id*/
					m_cout_txt << *t << " ";
					/*successful write and go into next chosen parameter id*/
					++loop_varianle;
				}
				++iterator_count;
			}
			/*finish one row write*/
			m_cout_txt << std::endl;
			row_parameter_vector.clear();
		}
	}
	m_cin_txt.close();
	m_cout_txt.close();
	successorfalse = true;
	return successorfalse;
}

}//namespace readtxt

#endif // !TACKLE_TXT_DATA_READ_TXT_DATA



